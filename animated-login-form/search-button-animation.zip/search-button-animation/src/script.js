$('.search-button').click(function(){
  $(this).parent().toggleClass('open');
});